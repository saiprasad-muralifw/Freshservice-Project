document.onreadystatechange = function() {
  if (document.readyState === 'interactive') renderApp();

  function renderApp() {
    const onInit = app.initialized();

    onInit
      .then(function getClient(_client) {
        window.client = _client;
        client.events.on('app.activated', renderContactName);
        client.instance.resize({ height: '150px' });
      })
      .catch(handleErr);
  }
};
function openModalBtn() {
  try {
    const data = client.interface.trigger('showModal', {
    title: 'Oracle',
    backdrop: true,
    template: './modal.html' });
    console.log(data); // success message
  } catch (error) {
      // failure operation
    console.error(error);
  }
}
function renderContactName() {
  const textElement = document.getElementById('apptext');
  client.data
    .get('requester')
    .then(function(payload) {
      textElement.innerHTML = `Data Method returned: ${payload.requester.name}`;
    })
    .catch(handleErr);
}

function handleErr(err = 'None') {
  console.error(`Error occured. Details:`, err);
}
